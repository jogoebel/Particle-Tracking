import numpy as np
import matplotlib.pyplot as plt

def histogram_plotting(TARDIS_df, PYTHON_df,max_dt,log_scale):
    
    n_cols = int(np.ceil(np.sqrt(max_dt)))
    n_rows = int(np.ceil(max_dt / n_cols))
    
    fig, axs = plt.subplots(n_rows, n_cols, figsize=(5 * n_cols, 4 * n_rows))
    axs = axs.flatten()
    
    for i, col_name in enumerate(TARDIS_df.columns):  # Iterate through column names
        axs[i].hist(TARDIS_df[col_name], bins=20, alpha=0.5, label='TARDIS', edgecolor='black', density=True)
        axs[i].hist(PYTHON_df[col_name], bins=20, alpha=0.5, label='PYTHON', edgecolor='black', density=True)
        
        axs[i].set_xlabel('Displacement (nm)')
        axs[i].set_ylabel('Probability Density')
        axs[i].set_title(f'Jump Distances for {col_name}')
        axs[i].legend(loc='upper right')
    
    if log_scale == True:
            ax.set_yscale('log')  # Set y-axis to logarithmic scale
 
    plt.tight_layout()
    return plt.show()
